"""verify6 (independent verifier of milestone M7, 2026-10-11): replay an input log from power-on in ONE fresh,
isolated NesHawk and keep, after every input, the whole 2 KB RAM and the whole 8 KB cartridge RAM.

My own code. From the harness it uses only zelda.emulator.BizHawk (launch + TCP bridge). Commands sent to the bridge:
'state', 'step 1 <buttons>', 'ram', 'ramd', 'screenshot' and, after the last input, a few 'ramd' reads of NesHawk-only
memory domains (core evidence). No savestate command, no reset, no memory write (the standard bridge has none; this
script also checks bridge.lua's text for write calls and records the result).

    python verify6_replay.py --tag r1
    python verify6_replay.py --tag r2 --shots 52000-68772

Outputs (logs/m7/):
    verify6_<tag>.ram.npy      uint8 [n+1, 2048]   row i = RAM after input i (row 0 = power-on, before any input)
    verify6_<tag>.wram.npy     uint8 [n+1, 8192]   cartridge RAM $6000-$7FFF, same rows
    verify6_<tag>.fc.npy       int32 [n+1, 2]      BizHawk framecount, lag count after input i
    verify6_<tag>.meta.json    pid, command line, core evidence, power-on cart RAM, final sha1s
    verify6_<tag>.emu.log      EmuHawk's stdout
    verify6_shots/<tag>_fNNNNN.png   screenshot taken right after input NNNNN (if --shots)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from zelda.emulator import BizHawk, LOGS_DIR, ROM, BRIDGE_LUA  # noqa: E402

OUT = LOGS_DIR / "m7"
P1 = ("Up", "Down", "Left", "Right", "Select", "Start", "B", "A")
WRITE_WORDS = ("write_u8", "writebyte", "write_bytes", "write_u16", "write_s8", "write_u32", "memory.write",
               "mainmemory.write", "poke")


def read_log(path: Path):
    """(header lines, list of tuples of button names, problems). One line = one input frame; '' = nothing held."""
    txt = path.read_bytes().decode("utf-8")
    lines = txt.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    head, frames, bad = [], [], []
    for ln, raw in enumerate(lines, 1):
        line = raw.rstrip("\r")
        if line.startswith("#"):
            head.append(line)
            if frames:
                bad.append(f"line {ln}: comment inside the log {line!r}")
            continue
        toks = tuple(t for t in line.split(",") if t)
        i = len(frames) + 1
        for t in toks:
            if t not in P1:
                bad.append(f"input {i} (line {ln}): token {t!r} is not a controller-1 button")
        if len(set(toks)) != len(toks):
            bad.append(f"input {i}: a button twice in {line!r}")
        if ",".join(toks) != line:
            bad.append(f"input {i}: odd formatting {line!r}")
        if "Left" in toks and "Right" in toks:
            bad.append(f"input {i}: Left+Right")
        if "Up" in toks and "Down" in toks:
            bad.append(f"input {i}: Up+Down")
        frames.append(toks)
    return head, frames, bad


def ranges(spec):
    out = set()
    for part in (spec or "").replace("\n", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-")
            out.update(range(int(a), int(b) + 1))
        else:
            out.add(int(part))
    return out


class Chan:
    """My own request/response loop on the bridge socket (the wrapper's buffered reader loses data if a recv fails;
    under memory pressure Windows answers recv with WinError 10055). A failed recv or send is simply tried again;
    nothing is re-sent that was already sent, so a command can never run twice."""

    def __init__(self, e):
        self.s = e.conn
        self.buf = bytearray()
        self.retries = 0

    def _again(self, ex):
        if getattr(ex, "winerror", None) != 10055:
            raise ex
        self.retries += 1
        time.sleep(0.25)

    def cmd(self, line: str) -> str:
        data = (line + chr(10)).encode()
        sent = 0
        while sent < len(data):
            try:
                sent += self.s.send(data[sent:])
            except OSError as ex:
                self._again(ex)
        while True:
            k = self.buf.find(bytes([10]))
            if k >= 0:
                resp = bytes(self.buf[:k]).decode()
                del self.buf[:k + 1]
                break
            try:
                chunk = self.s.recv(1 << 16)
            except OSError as ex:
                self._again(ex)
                continue
            if not chunk:
                raise RuntimeError("bridge connection closed")
            self.buf += chunk
        if resp.startswith("err "):
            raise RuntimeError(resp)
        return resp

    def ram(self, addr, length):
        return bytes.fromhex(self.cmd(f"ram {addr} {length}"))

    def ramd(self, dom, addr, length):
        return bytes.fromhex(self.cmd(f"ramd {dom} {addr} {length}"))


def kv(line):
    d = {}
    for tok in line.split():
        k, _, v = tok.partition("=")
        d[k] = int(v)
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    ap.add_argument("--inputs", default=str(OUT / "e2.inputs.txt"))
    ap.add_argument("--shots", default=None)
    ap.add_argument("--upto", type=int, default=None)
    a = ap.parse_args()
    inp = Path(a.inputs)
    head, frames, bad = read_log(inp)
    shots = ranges(a.shots)
    shot_dir = OUT / "verify6_shots"
    if shots:
        shot_dir.mkdir(parents=True, exist_ok=True)
    n = len(frames) if a.upto is None else min(len(frames), a.upto)
    btxt = BRIDGE_LUA.read_text(encoding="utf-8", errors="replace")
    meta = {"tag": a.tag, "inputs": str(inp), "inputs_sha1": hashlib.sha1(inp.read_bytes()).hexdigest(),
            "header": head, "n_inputs_in_file": len(frames), "n_replayed": n, "parse_problems": bad,
            "rom": str(ROM), "rom_sha1": hashlib.sha1(ROM.read_bytes()).hexdigest(),
            "rom_md5": hashlib.md5(ROM.read_bytes()).hexdigest(),
            "bridge_sha1": hashlib.sha1(BRIDGE_LUA.read_bytes()).hexdigest(),
            "bridge_write_words_found": [w for w in WRITE_WORDS if w in btxt],
            "started": time.strftime("%Y-%m-%d %H:%M:%S")}
    print(f"[{a.tag}] {len(frames)} inputs in file, replaying {n}; header {head}; parse problems {len(bad)}",
          flush=True)
    ram = np.lib.format.open_memmap(OUT / f"verify6_{a.tag}.ram.npy", mode="w+", dtype=np.uint8, shape=(n + 1, 2048))
    wram = np.lib.format.open_memmap(OUT / f"verify6_{a.tag}.wram.npy", mode="w+", dtype=np.uint8,
                                     shape=(n + 1, 8192))
    fc = np.zeros((n + 1, 2), dtype=np.int32)
    t0 = time.time()
    e = BizHawk(isolate=True, core="NesHawk", log_name=f"m7/verify6_{a.tag}.emu.log")
    try:
        meta["pid"] = e.proc.pid
        meta["cmdline"] = [str(x) for x in e.proc.args]
        meta["private_dir"] = str(e.private_dir)
        (OUT / f"verify6_{a.tag}.pid").write_text(str(e.proc.pid), encoding="utf-8")
        conf = json.loads((e.private_dir / "config.ini").read_text(encoding="utf-8"))
        meta["config_preferred_core_NES"] = conf["PreferredCores"].get("NES")
        meta["config_saveram_path"] = [p["Path"] for p in conf["PathEntries"]["Paths"]
                                       if p.get("System") == "NES" and p.get("Type") == "Save RAM"]
        meta["config_rewind_enabled"] = conf.get("Rewind", {}).get("Enabled")
        meta["saveram_files_at_launch"] = [p.name for p in (e.private_dir / "SaveRAM").glob("*")]
        print(f"[{a.tag}] pid {e.proc.pid} private {e.private_dir}", flush=True)
        ch = Chan(e)
        s0 = kv(ch.cmd("state"))
        meta["poweron_state"] = s0
        r0 = ch.ram(0, 0x800)
        w0 = ch.ramd("WRAM", 0, 0x2000)
        ram[0] = np.frombuffer(r0, dtype=np.uint8)
        wram[0] = np.frombuffer(w0, dtype=np.uint8)
        fc[0] = (s0["frame"], s0["lag"])
        meta["poweron_ram_sha1"] = hashlib.sha1(r0).hexdigest()
        meta["poweron_wram_sha1"] = hashlib.sha1(w0).hexdigest()
        meta["poweron_wram_distinct_bytes"] = sorted(set(w0))
        for i in range(1, n + 1):
            d = kv(ch.cmd(f"step 1 {','.join(frames[i - 1]) or '-'}"))
            fc[i] = (d["frame"], d["lag"])
            ram[i] = np.frombuffer(ch.ram(0, 0x800), dtype=np.uint8)
            wram[i] = np.frombuffer(ch.ramd("WRAM", 0, 0x2000), dtype=np.uint8)
            if i in shots:
                ch.cmd(f"screenshot {shot_dir / f'{a.tag}_f{i:05d}.png'}")
            if i % 2000 == 0:
                print(f"[{a.tag}] {i}/{n} frames, {time.time() - t0:.0f}s, socket retries {ch.retries}", flush=True)
        rN = ch.ram(0, 0x800)
        wN = ch.ramd("WRAM", 0, 0x2000)
        meta["final_state"] = kv(ch.cmd("state"))
        meta["socket_retries"] = ch.retries
        meta["final_ram_sha1"] = hashlib.sha1(rN).hexdigest()
        meta["final_wram_sha1"] = hashlib.sha1(wN).hexdigest()
        # core evidence: memory domains only NesHawk has (a failed read comes back as an 'err' line or kills the
        # bridge - either way it is after the last input, and is recorded)
        dom = {}
        for name, ln in (("PALRAM", 32), ("OAM", 16)):
            try:
                dom[name] = ch.ramd(name, 0, ln).hex()
            except Exception as ex:  # noqa: BLE001
                dom[name] = f"ERR {ex}"[:120]
                break
        meta["domain_probe_after_last_input"] = dom
    finally:
        e.close()
    meta["closed"] = True
    meta["exit_code"] = e.proc.poll()
    meta["seconds"] = round(time.time() - t0, 1)
    meta["framecount_step_ok"] = bool(np.all(np.diff(fc[:, 0]) == 1))
    meta["framecount_first_last"] = [int(fc[0, 0]), int(fc[-1, 0])]
    meta["lag_total"] = int(fc[-1, 1])
    np.save(OUT / f"verify6_{a.tag}.fc.npy", fc)
    ram.flush()
    wram.flush()
    meta["all_frames_ram_sha1"] = hashlib.sha1(np.ascontiguousarray(ram).tobytes()).hexdigest()
    meta["all_frames_wram_sha1"] = hashlib.sha1(np.ascontiguousarray(wram).tobytes()).hexdigest()
    (OUT / f"verify6_{a.tag}.meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    print(f"[{a.tag}] done in {meta['seconds']}s final RAM sha1 {meta['final_ram_sha1']} lag {meta['lag_total']} "
          f"exit {meta['exit_code']}", flush=True)


if __name__ == "__main__":
    main()
