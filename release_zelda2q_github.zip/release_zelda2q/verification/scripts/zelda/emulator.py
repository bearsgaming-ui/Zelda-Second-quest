"""Python side of the BizHawk bridge. Launches EmuHawk with bridge.lua and drives it over TCP."""
from __future__ import annotations

import json
import os
import socket
import uuid
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Sequence

HARNESS_DIR = Path(__file__).resolve().parent.parent
ROOT = HARNESS_DIR.parent
BIZHAWK_DIR = ROOT / "BizHawk-2.11.1-win-x64"
EMUHAWK = BIZHAWK_DIR / "EmuHawk.exe"
ROM = BIZHAWK_DIR / "Legend of Zelda, The (USA) (Rev 1).nes"
BRIDGE_LUA = HARNESS_DIR / "bridge.lua"
STATES_DIR = HARNESS_DIR / "states"
SHOTS_DIR = HARNESS_DIR / "shots"
LOGS_DIR = HARNESS_DIR / "logs"
VIDEO_DIR = HARNESS_DIR / "video"

BUTTONS = ("Up", "Down", "Left", "Right", "Select", "Start", "B", "A")


def _click_really_quit(timeout: float = 4.0) -> bool:
    """Find EmuHawk's 'Really quit?' A/V dialog and click its Yes button (Windows only)."""
    try:
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        BM_CLICK = 0x00F5
        EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        t0 = time.time()
        while time.time() - t0 < timeout:
            dlg = u.FindWindowW(None, "Really quit?")
            if dlg:
                found = []

                def cb(h, _):
                    buf = ctypes.create_unicode_buffer(64)
                    u.GetWindowTextW(h, buf, 64)
                    if "yes" in buf.value.replace("&", "").lower():
                        found.append(h)
                    return True
                u.EnumChildWindows(dlg, EnumProc(cb), 0)
                if found:
                    u.PostMessageW(found[0], BM_CLICK, 0, 0)
                    return True
            time.sleep(0.1)
    except Exception:
        pass
    return False


@dataclass
class State:
    frame: int = 0
    mode: int = 0
    sub: int = 0
    level: int = 0
    room: int = 0
    x: int = 0
    y: int = 0
    dir: int = 0
    hp: int = 0
    hpfrac: int = 0
    rupees: int = 0
    keys: int = 0
    bombs: int = 0
    sword: int = 0
    bitem: int = 0
    triforce: int = 0
    paused: int = 0
    scroll: int = 0
    retroom: int = 0
    anim: int = 0
    kills: int = 0          # $50 HelpDropCount (kill streak toward the forced drop)
    # Added 2026-10-09 (Second Quest M0, plan Q2). bridge.lua reports them after the older keys; a state line from
    # an older bridge or trace simply leaves them at 0 (State.parse ignores missing keys).
    upd: int = 0            # $11 IsUpdatingMode (0 on a mode's init frame)
    fc: int = 0             # $15 FrameCounter
    rng: int = 0            # $18 Random (first LFSR byte)
    flute: int = 0          # $3C FluteTimer
    helpv: int = 0          # $51 HelpDropValue (forced drop will be bombs)
    gridoff: int = 0        # $394 ObjGridOffset (Link)
    frac: int = 0           # $3A8 ObjPosFrac (Link)
    telidx: int = 0         # $523 TeleportingLevelIndex (recorder counter)
    kcycle: int = 0         # $52A WorldKillCycle
    wkills: int = 0         # $627 WorldKillCount
    quest: int = 0          # $62D QuestNumbers[0]: 1 = Second Quest
    lag: int = 0
    raw: dict = field(default_factory=dict, repr=False)

    @classmethod
    def parse(cls, line: str) -> "State":
        kv = {}
        for tok in line.split():
            k, _, v = tok.partition("=")
            kv[k] = int(v)
        s = cls(**{k: v for k, v in kv.items() if k in cls.__dataclass_fields__})
        s.raw = kv
        return s

    @property
    def hearts(self) -> float:
        full = self.hp & 0x0F
        return full + (1.0 if self.hpfrac >= 0x80 else 0.5 if self.hpfrac > 0 else 0.0)

    @property
    def containers(self) -> int:
        return (self.hp >> 4) + 1

    def __str__(self) -> str:
        return (f"f{self.frame} mode={self.mode:02x}/{self.sub:02x} L{self.level} room={self.room:02x} "
                f"pos=({self.x},{self.y}) dir={self.dir} hp={self.hearts}/{self.containers} "
                f"rup={self.rupees} sword={self.sword} lag={self.lag}")


class BizHawk:
    """One EmuHawk instance driven frame by frame."""

    def __init__(self, rom: Path = ROM, fast: bool = True, log_name: str | None = None,
                 clean_sram: bool = True, record: str | None = None, core: str | None = None,
                 isolate: bool = True):
        """record=<session name>: dump video live (savestate jumps included) and log every frame's
        input, state and notes to logs/<session>.* so the session can be rendered with the panel."""
        for d in (STATES_DIR, SHOTS_DIR, LOGS_DIR, VIDEO_DIR):
            d.mkdir(parents=True, exist_ok=True)
        self.record = record
        self.trace_lines: list[str] = []
        # isolate=True (2026-10-09): every instance gets a private copy of config.ini whose NES "Save RAM" path is a
        # private folder, so parallel emulators can never hand each other a battery save (an emulator closing flushes
        # the game's save; another one launching would then start from a saved game). core= overrides the NES core.
        self.private_dir = None
        cfg_args = []
        if isolate or core:
            self.private_dir = HARNESS_DIR / "emu_tmp" / f"{os.getpid()}_{uuid.uuid4().hex[:8]}"
            (self.private_dir / "SaveRAM").mkdir(parents=True, exist_ok=True)
            conf = json.loads((BIZHAWK_DIR / "config.ini").read_text(encoding="utf-8-sig"))
            for e in conf["PathEntries"]["Paths"]:
                if e.get("System") == "NES" and e.get("Type") == "Save RAM":
                    e["Path"] = str(self.private_dir / "SaveRAM")
            if core:
                conf["PreferredCores"]["NES"] = core
            # Rewind buys nothing here (the bridge uses msave/mload) but its 512 MB buffer took a NesHawk instance from
            # ~275 MB to ~800 MB; off, many more parallel instances fit in 16 GB.
            if "Rewind" in conf:
                conf["Rewind"]["Enabled"] = False
            cfg = self.private_dir / "config.ini"
            cfg.write_text(json.dumps(conf, indent=1), encoding="utf-8")
            cfg_args = [f"--config={cfg}"]
        if clean_sram:
            # The game's battery save persists across launches; a from-power-on run must start clean.
            for p in (BIZHAWK_DIR / "NES" / "SaveRAM").glob("*.SaveRAM*"):
                if not isolate:
                    p.unlink()
            if self.private_dir:
                for p in (self.private_dir / "SaveRAM").glob("*.SaveRAM*"):
                    p.unlink()
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("127.0.0.1", 0))
        srv.listen(1)
        port = srv.getsockname()[1]
        (HARNESS_DIR / ".bridge_port").write_text(str(port))
        log_name = log_name or f"emuhawk_{int(time.time())}.log"
        # Keep the previous launch's log as <name>.prev: run_until.sh relaunches straight after a silent
        # death, and reopening with "w" used to destroy the one log that could say why it died.
        log_path = LOGS_DIR / log_name
        try:
            if log_path.exists() and log_path.stat().st_size > 0:
                log_path.replace(log_path.with_name(log_path.stem + ".prev" + log_path.suffix))
        except OSError:
            pass
        self._logfile = open(log_path, "w")
        args = [str(EMUHAWK)] + cfg_args + [f"--lua={BRIDGE_LUA}", f"--userdata=port:{port}"]
        if record:
            self.video_path = VIDEO_DIR / f"{record}.mkv"
            args += ["--dump-type=ffmpeg", f"--dump-name={self.video_path}"]
        args.append(str(rom))
        self.proc = subprocess.Popen(args, cwd=str(BIZHAWK_DIR), stdout=self._logfile, stderr=subprocess.STDOUT)
        srv.settimeout(60)
        try:
            self.conn, _ = srv.accept()
        except socket.timeout:
            self.proc.kill()
            raise RuntimeError("EmuHawk never connected to the bridge; see " + str(LOGS_DIR / log_name))
        finally:
            srv.close()
        self.conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.conn.settimeout(120)
        self._rf = self.conn.makefile("rb")
        self.inputs: list[tuple[str, ...]] = []   # one entry per emulated frame since power-on
        self.events: list[tuple[int, str]] = []   # (frame, text) notes from the bot, for overlays
        self.input_log_valid = True                 # False once a savestate load breaks the frame chain
        assert self.cmd("ping") == "pong"
        if record:
            self.cmd("trace on")
        if fast:
            self.fast()

    # -- low level -------------------------------------------------------
    def cmd(self, line: str) -> str:
        self.conn.sendall((line + "\n").encode())
        resp = self._rf.readline()
        if not resp:
            # Say HOW the bridge died. An EmuHawk that ran its orderly Close() exits with 0; a crash or a
            # kill leaves 0xC0000005, 0xE0434352 or 1. A seven-agent diagnosis of six drops on 2026-09-15
            # could not tell those apart, because nothing recorded the exit code or the time.
            import time as _time
            code = None
            try:
                code = self.proc.wait(timeout=2)
            except Exception:
                pass
            how = "still running" if code is None else f"exit code {code} (0x{code & 0xFFFFFFFF:08X})"
            raise RuntimeError(f"bridge connection lost at {_time.strftime('%H:%M:%S')}: EmuHawk {how}; "
                               f"log {getattr(self._logfile, 'name', '?')}")
        resp = resp.decode().rstrip("\n")
        if resp.startswith("err "):
            raise RuntimeError(resp)
        return resp

    # -- control ---------------------------------------------------------
    def step(self, buttons: Iterable[str] | str = (), frames: int = 1) -> State:
        if isinstance(buttons, str):
            buttons = tuple(b for b in buttons.split(",") if b)
        btn = tuple(buttons)
        for b in btn:
            if b not in BUTTONS:
                raise ValueError(f"unknown button {b!r}")
        self.inputs.extend([btn] * frames)
        resp = self.cmd(f"step {frames} {','.join(btn) or '-'}")
        if self.record:
            lines = resp.split(";")
            self.trace_lines.extend(lines)
            return State.parse(lines[-1])
        return State.parse(resp)

    def press(self, *buttons: str, hold: int = 1, release: int = 1) -> State:
        """Tap buttons: hold for `hold` frames, then release for `release` frames."""
        s = self.step(buttons, hold)
        if release:
            s = self.step((), release)
        return s

    def state(self) -> State:
        return State.parse(self.cmd("state"))

    def ram(self, addr: int, length: int = 1) -> bytes:
        return bytes.fromhex(self.cmd(f"ram {addr} {length}"))

    def byte(self, addr: int) -> int:
        return self.ram(addr, 1)[0]

    def ram_domain(self, domain: str, addr: int, length: int) -> bytes:
        """Read from another BizHawk memory domain, e.g. 'WRAM' (cart RAM at $6000, offset 0) or 'System Bus'."""
        return bytes.fromhex(self.cmd(f"ramd {domain} {addr} {length}"))

    def bus(self, addr: int, length: int = 1) -> bytes:
        """Read CPU-address-space bytes: $0000-$07FF from RAM, $6000-$7FFF from cart WRAM."""
        if addr < 0x800:
            return self.ram(addr, length)
        if 0x6000 <= addr < 0x8000:
            return self.ram_domain("WRAM", addr - 0x6000, length)
        raise ValueError(f"unsupported bus address {addr:#x}")

    def save(self, name: str) -> Path:
        p = STATES_DIR / f"{name}.State"
        self.cmd(f"save {p}")
        return p

    def load(self, name: str) -> State:
        p = STATES_DIR / f"{name}.State"
        r = self.cmd(f"load {p}")
        if r != "ok":
            raise RuntimeError(f"savestate load failed: {p}")
        self.input_log_valid = False
        return self.state()

    # in-memory savestates for search (fast; not persisted)
    def msave(self) -> str:
        return self.cmd("msave")

    def mload(self, sid: str) -> State:
        self.cmd(f"mload {sid}")
        self.input_log_valid = False
        return self.state()

    def mfree(self, sid: str) -> None:
        self.cmd(f"mfree {sid}")

    def branch(self, strings, addrs, checkpoints=None, every: int | None = None, stop_ne=(), stop_eq=()) -> list:
        """Evaluate several input strings from the current state in one bridge round trip (bridge.lua 'branch',
        plan X6). Each string runs from the current state; the emulator ends in exactly the state it started in, so
        the input log stays valid.

        strings     K input strings; each is a sequence of per-frame entries, an int button mask (bit i = BUTTONS[i]:
                    1 Up, 2 Down, 4 Left, 8 Right, 16 Select, 32 Start, 64 B, 128 A) or a tuple/str of button names
        addrs       RAM to sample: ints, or (addr, length) pairs
        checkpoints frame counts within a string after which to sample (the end is always sampled)
        every       sample every N frames instead of at checkpoints
        stop_ne     addresses: end a string on the first frame that address differs from its value at the start
        stop_eq     (addr, value) pairs: end a string on the first frame that address equals value
        Returns one dict per string: frames (frames run), lag (BizHawk lag frames), samples {frame: bytes} for the
        checkpoints reached, end (bytes at the last frame run). Bytes follow the order of addrs.
        L+R and U+D are refused (house rule). On an emulator opened with record=..., the branch frames go into
        the A/V dump (as msave/mload search frames do), so search on a separate instance."""
        def mask_of(entry) -> int:
            if isinstance(entry, int):
                m = entry
            else:
                names = tuple(b for b in entry.split(",") if b) if isinstance(entry, str) else tuple(entry)
                m = 0
                for b in names:
                    if b not in BUTTONS:
                        raise ValueError(f"unknown button {b!r}")
                    m |= 1 << BUTTONS.index(b)
            if not 0 <= m <= 255:
                raise ValueError(f"bad button mask {m}")
            if m & 3 == 3 or m & 12 == 12:
                raise ValueError(f"opposite directions in mask {m:#04x}")
            return m

        def encode(seq) -> str:
            items, prev, run = [], None, 0
            for e in seq:
                m = mask_of(e)
                if m == prev:
                    run += 1
                    continue
                if prev is not None:
                    items.append(f"{prev:02x}" + (f":{run}" if run > 1 else ""))
                prev, run = m, 1
            if prev is not None:
                items.append(f"{prev:02x}" + (f":{run}" if run > 1 else ""))
            if not items:
                raise ValueError("empty input string")
            return ".".join(items)

        ranges = []
        for a in addrs:
            addr, n = (a, 1) if isinstance(a, int) else (int(a[0]), int(a[1]))
            if not (0 <= addr and n >= 1 and addr + n <= 0x800):
                raise ValueError(f"bad RAM range {a!r}")
            ranges.append(f"{addr}+{n}" if n > 1 else str(addr))
        if not ranges:
            raise ValueError("branch needs at least one address")
        if every:
            cps = f"*{int(every)}"
        elif checkpoints:
            cps = ",".join(str(int(c)) for c in sorted(set(checkpoints)))
        else:
            cps = "-"
        opts = [f"stopne={int(a)}" for a in stop_ne] + [f"stopeq={int(a)}:{int(v)}" for a, v in stop_eq]
        encoded = [encode(s) for s in strings]
        resp = self.cmd(" ".join(["branch", ",".join(ranges), cps] + opts + encoded))
        parts = resp.split(" ")
        if parts[0] != "ok" or int(parts[1]) != len(encoded) or len(parts) != 2 + len(encoded):
            raise RuntimeError(f"bad branch reply: {resp[:200]}")
        out = []
        for r in parts[2:]:
            frames, lag, samples = r.split("/", 2)
            pts = []
            for smp in samples.split(";"):
                f, _, hx = smp.partition(":")
                pts.append((int(f), bytes.fromhex(hx)))
            end = pts.pop()
            out.append({"frames": int(frames), "lag": int(lag), "samples": dict(pts), "end": end[1]})
        return out

    def screenshot(self, name: str) -> Path:
        p = SHOTS_DIR / f"{name}.png"
        self.cmd(f"screenshot {p}")
        return p

    def fast(self) -> None:
        self.cmd("fast")

    def normal(self) -> None:
        self.cmd("normal")

    def reset(self) -> State:
        self.inputs.clear()
        self.input_log_valid = True
        return State.parse(self.cmd("reset"))

    def wait(self, frames: int) -> State:
        return self.step((), frames)

    def wait_until(self, pred, max_frames: int = 600, buttons: Sequence[str] = ()) -> State:
        s = self.state()
        for _ in range(max_frames):
            if pred(s):
                return s
            s = self.step(buttons, 1)
        raise TimeoutError(f"condition not met after {max_frames} frames; last state {s}")

    def note(self, text: str) -> None:
        """Record what the bot is doing right now (attached to the next frame)."""
        self.events.append((len(self.inputs) + 1, text))

    def save_inputs(self, name: str) -> Path:
        p = LOGS_DIR / f"{name}.inputs.txt"
        with open(p, "w") as f:
            f.write(f"# frames={len(self.inputs)} valid_from_poweron={self.input_log_valid}\n")
            for btn in self.inputs:
                f.write(",".join(btn) + "\n")
        with open(LOGS_DIR / f"{name}.events.txt", "w") as f:
            for frame, text in self.events:
                f.write(f"{frame}\t{text}\n")
        return p

    def save_session(self) -> None:
        """Write logs/<record>.{inputs,events,trace}.txt indexed by video frame (frames stepped since launch)."""
        name = self.record
        with open(LOGS_DIR / f"{name}.inputs.txt", "w") as f:
            f.write(f"# frames={len(self.inputs)} session=1\n")
            for btn in self.inputs:
                f.write(",".join(btn) + "\n")
        with open(LOGS_DIR / f"{name}.events.txt", "w") as f:
            for frame, text in self.events:
                f.write(f"{frame}\t{text}\n")
        with open(LOGS_DIR / f"{name}.trace.txt", "w") as f:
            for i, (btn, line) in enumerate(zip(self.inputs, self.trace_lines)):
                f.write(f"{i + 1}\t{','.join(btn)}\t{line}\n")

    def close(self) -> None:
        if self.record:
            try:
                self.save_session()
            except Exception as e:  # never lose the emulator shutdown over a log
                print("session save failed:", e)
        try:
            self.cmd("quit")
        except Exception:
            pass
        try:
            self.conn.close()
        except Exception:
            pass
        if self.record:
            _click_really_quit()   # BizHawk asks "Really quit?" while recording A/V; answer Yes for it
        try:
            self.proc.wait(timeout=12 if self.record else 3)
        except Exception:
            self.proc.kill()
        self._logfile.close()
        if self.private_dir:                      # the private config + battery save of this instance
            import shutil
            shutil.rmtree(self.private_dir, ignore_errors=True)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
