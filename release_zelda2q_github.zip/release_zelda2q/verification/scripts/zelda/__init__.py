# minimal package for the verify scripts (the project's zelda/__init__.py also imports modules not shipped here)
from .emulator import BizHawk, State  # noqa: F401
