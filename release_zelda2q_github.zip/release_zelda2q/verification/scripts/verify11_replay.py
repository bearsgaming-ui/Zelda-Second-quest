﻿"""verify11 (independent verifier of M10 run h1, 2026-11-17; copy of verify9_replay.py): replay an input log from power-on in ONE fresh,
isolated NesHawk. Per input: sha1 of the 2 KB RAM and of the 8 KB cart RAM; with --keep the whole 2 KB RAM of every
row (memmap, ~230 MB). Screenshots right after chosen inputs (--shots). After the last input, --extra N more frames
with NO buttons are stepped only to take pictures of what follows (kept separately, not part of the run).

Bridge commands used: 'state', 'step 1 <buttons>', 'ram', 'ramd', 'screenshot'. No savestate, no reset, no write.
Derived from verify8_replay.py (verifier code, not the builder's).

    python verify11_replay.py --tag r1 --keep --shots 220-250,112380-112651 --extra 12
    python verify11_replay.py --tag r2
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from zelda.emulator import BizHawk, LOGS_DIR, ROM, BRIDGE_LUA  # noqa: E402
from verify6_replay import read_log, Chan, kv, WRITE_WORDS, ranges  # noqa: E402

OUT = LOGS_DIR / "m11"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    ap.add_argument("--inputs", default=str(LOGS_DIR / "m10" / "h1.inputs.txt"))
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--shots", default=None)
    ap.add_argument("--extra", type=int, default=0)
    a = ap.parse_args()
    inp = Path(a.inputs)
    head, frames, bad = read_log(inp)
    n = len(frames)
    shots = ranges(a.shots)
    shot_dir = OUT / "verify11_shots"
    shot_dir.mkdir(exist_ok=True)
    btxt = BRIDGE_LUA.read_text(encoding="utf-8", errors="replace")
    meta = {"tag": a.tag, "inputs": str(inp), "inputs_sha1": hashlib.sha1(inp.read_bytes()).hexdigest(),
            "header": head, "n": n, "parse_problems": bad, "rom_sha1": hashlib.sha1(ROM.read_bytes()).hexdigest(),
            "bridge_sha1": hashlib.sha1(BRIDGE_LUA.read_bytes()).hexdigest(),
            "bridge_write_words_found": [w for w in WRITE_WORDS if w in btxt],
            "started": time.strftime("%Y-%m-%d %H:%M:%S"), "complete": False}
    hr = np.zeros((n + 1, 20), dtype=np.uint8)
    hw = np.zeros((n + 1, 20), dtype=np.uint8)
    fc = np.zeros((n + 1, 2), dtype=np.int32)
    if a.keep:
        ram = np.lib.format.open_memmap(OUT / f"verify11_{a.tag}.ram.npy", mode="w+", dtype=np.uint8,
                                        shape=(n + 1, 2048))
    prog = OUT / f"verify11_{a.tag}.progress.txt"
    t0 = time.time()
    e = BizHawk(isolate=True, core="NesHawk", log_name=f"m11/verify11_{a.tag}.emu.log")
    extra_rows = []
    try:
        meta["pid"] = e.proc.pid
        (OUT / f"verify11_{a.tag}.pid").write_text(str(e.proc.pid), encoding="utf-8")
        conf = json.loads((e.private_dir / "config.ini").read_text(encoding="utf-8"))
        meta["config_preferred_core_NES"] = conf["PreferredCores"].get("NES")
        meta["saveram_files_at_launch"] = [p.name for p in (e.private_dir / "SaveRAM").glob("*")]
        print(f"[{a.tag}] pid {e.proc.pid} n {n} parse problems {len(bad)}", flush=True)
        ch = Chan(e)
        s0 = kv(ch.cmd("state"))
        meta["poweron_state"] = s0
        for i in range(0, n + 1):
            if i:
                d = kv(ch.cmd(f"step 1 {','.join(frames[i - 1]) or '-'}"))
                fc[i] = (d["frame"], d["lag"])
            else:
                fc[0] = (s0["frame"], s0["lag"])
            r = ch.ram(0, 0x800)
            w = ch.ramd("WRAM", 0, 0x2000)
            if i == 0:
                meta["poweron_ram_sha1"] = hashlib.sha1(r).hexdigest()
                meta["poweron_wram_sha1"] = hashlib.sha1(w).hexdigest()
                meta["poweron_wram_distinct_bytes"] = sorted(set(w))
            hr[i] = np.frombuffer(hashlib.sha1(r).digest(), dtype=np.uint8)
            hw[i] = np.frombuffer(hashlib.sha1(w).digest(), dtype=np.uint8)
            if a.keep:
                ram[i] = np.frombuffer(r, dtype=np.uint8)
            if i in shots:
                ch.cmd(f"screenshot {shot_dir / f'{a.tag}_i{i:06d}.png'}")
            if i % 4000 == 0:
                msg = f"[{a.tag}] {i}/{n} {time.time() - t0:.0f}s retries {ch.retries}"
                print(msg, flush=True)
                prog.write_text(msg + "\n", encoding="utf-8")
        meta["final_ram_sha1"] = hashlib.sha1(r).hexdigest()
        meta["final_wram_sha1"] = hashlib.sha1(w).hexdigest()
        meta["final_state"] = kv(ch.cmd("state"))
        for k in range(1, a.extra + 1):
            d = kv(ch.cmd("step 1 -"))
            r = ch.ram(0, 0x800)
            extra_rows.append({"after_input": n + k, "frame": d["frame"], "ram_hex": r.hex()})
            ch.cmd(f"screenshot {shot_dir / f'{a.tag}_x{n + k:06d}.png'}")
        meta["socket_retries"] = ch.retries
    finally:
        e.close()
    meta["exit_code"] = e.proc.poll()
    meta["seconds"] = round(time.time() - t0, 1)
    meta["framecount_step_ok"] = bool(np.all(np.diff(fc[:, 0]) == 1))
    meta["framecount_first_last"] = [int(fc[0, 0]), int(fc[-1, 0])]
    meta["lag_total"] = int(fc[-1, 1])
    np.save(OUT / f"verify11_{a.tag}.hr.npy", hr)
    np.save(OUT / f"verify11_{a.tag}.hw.npy", hw)
    np.save(OUT / f"verify11_{a.tag}.fc.npy", fc)
    if a.keep:
        ram.flush()
    if extra_rows:
        (OUT / f"verify11_{a.tag}.extra.json").write_text(json.dumps(extra_rows), encoding="utf-8")
    meta["all_frames_hash_sha1"] = hashlib.sha1(hr.tobytes() + hw.tobytes()).hexdigest()
    meta["complete"] = True
    (OUT / f"verify11_{a.tag}.meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    msg = f"[{a.tag}] DONE {meta['seconds']}s final RAM sha1 {meta['final_ram_sha1']} lag {meta['lag_total']}"
    print(msg, flush=True)
    prog.write_text(msg + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

