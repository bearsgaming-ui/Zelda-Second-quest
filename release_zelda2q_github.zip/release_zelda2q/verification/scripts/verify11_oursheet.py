﻿"""verify11 (copy of verify9_oursheet.py): contact sheet of my NesHawk screenshots (picture right after input i).
    python verify9_oursheet.py <first> <last> <out.png> [prefix r1_i|r1_x]
"""
import sys
from pathlib import Path
from PIL import Image, ImageDraw

D = Path(__file__).resolve().parent / "logs" / "m11" / "verify11_shots"
lo, hi, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
tag = sys.argv[4] if len(sys.argv) > 4 else "r1"
ims = []
for i in range(lo, hi + 1):
    p = D / f"{tag}_i{i:06d}.png"
    if not p.exists():
        p = D / f"{tag}_x{i:06d}.png"
    if not p.exists():
        continue
    im = Image.open(p).convert("RGB")
    im = im.resize((im.width * 2, im.height * 2), Image.NEAREST)
    dr = ImageDraw.Draw(im)
    dr.rectangle((0, 0, 110, 14), fill=(0, 0, 0))
    dr.text((2, 1), ("i" if "_i" in p.name else "x") + str(i), fill=(255, 255, 0))
    ims.append(im)
cols = 5
w, h = ims[0].size
sheet = Image.new("RGB", (w * cols, h * ((len(ims) + cols - 1) // cols)), (40, 40, 40))
for k, im in enumerate(ims):
    sheet.paste(im, ((k % cols) * w, (k // cols) * h))
sheet.save(out)
print(out, sheet.size, len(ims))

