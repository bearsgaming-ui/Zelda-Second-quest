-- bridge.lua : runs inside EmuHawk. Connects to the Python controller over TCP
-- and executes newline-delimited commands, replying one line per command.
--
-- Commands:
--   ping                        -> pong
--   step <n> <buttons>          -> hold <buttons> (comma list or "-") for n frames, reply state
--   state                       -> reply state
--   ram <addr> <len>            -> hex bytes of main RAM
--   save <path> | load <path>   -> savestate to/from file
--   screenshot <path>           -> png
--   fast | normal               -> unthrottle / throttle
--   reset                       -> power-cycle core
--   quit                        -> exit EmuHawk
--   stepm <n>                   -> advance n frames WITHOUT touching the joypad (a loaded .bk2 movie supplies
--                                  the input), reply state
--   fields <name:addr,...>      -> replace the RAM fields of the state line ("fields default" restores the list
--                                  below); reply "ok <count>"
-- This bridge has no memory-write command. Runs are inputs only: pokes live in debug bridges used by probes
-- (probes/gap4_recorder/bridge_dbg.lua), never here.

local socket = require("socket.core")

local port = tonumber(userdata.get("port") or 0)
if not port or port == 0 then
  local f = io.open("G:/AI World Record/harness/.bridge_port", "r")
  if f then port = tonumber(f:read("*l")); f:close() end
end
assert(port and port > 0, "bridge: no port given")

local conn = socket.tcp()
conn:settimeout(15)
local ok, err = conn:connect("127.0.0.1", port)
assert(ok, "bridge: connect failed: " .. tostring(err))
conn:setoption("tcp-nodelay", true)
conn:settimeout(0.05)
console.log("bridge: connected on port " .. port)

-- Ordered list of RAM fields reported in every state line.
local FIELDS = {
  {"mode",     0x12},  -- game mode (5 = normal play, 7 = scrolling, 0xB = cave, ...)
  {"sub",      0x13},  -- routine index / submode
  {"level",    0x10},  -- 0 = overworld, 1-9 dungeon
  {"room",     0xEB},  -- screen id: high nybble row, low nybble col
  {"x",        0x70},  -- Link X
  {"y",        0x84},  -- Link Y
  {"dir",      0x98},  -- Link facing (1 R, 2 L, 4 D, 8 U)
  {"hp",       0x66F}, -- hi nybble = containers-1, lo nybble = full hearts
  {"hpfrac",   0x670},
  {"rupees",   0x66D},
  {"keys",     0x66E},
  {"bombs",    0x658},
  {"sword",    0x657},
  {"bitem",    0x656},
  {"triforce", 0x671},
  {"paused",   0xE0},
  {"scroll",   0xE8},
  {"retroom",  0x526},
  {"anim",     0xAC},
  {"kills",    0x50},  -- HelpDropCount: kill streak toward the forced drop (cap 10)
  -- added 2026-10-09 (Second Quest M0, plan Q2); appended so every older key keeps its name and meaning
  {"upd",      0x11},  -- IsUpdatingMode: 0 on a mode's init frame, 1 while it updates
  {"fc",       0x15},  -- FrameCounter (stalls on a missed NMI = real lag)
  {"rng",      0x18},  -- Random, first byte of the 13-byte LFSR $18-$24
  {"flute",    0x3C},  -- FluteTimer (recorder freeze)
  {"helpv",    0x51},  -- HelpDropValue: set when the 10th kill is a bomb kill (forced drop = bombs)
  {"gridoff",  0x394}, -- ObjGridOffset of Link
  {"frac",     0x3A8}, -- ObjPosFrac of Link ($00 / $80)
  {"telidx",   0x523}, -- TeleportingLevelIndex (recorder counter)
  {"kcycle",   0x52A}, -- WorldKillCycle (table-drop column)
  {"wkills",   0x627}, -- WorldKillCount (16 = fairy)
  {"quest",    0x62D}, -- QuestNumbers[slot 0]: 0 First Quest, 1 Second Quest
}
local DEFAULT_FIELDS = FIELDS

local BUTTONS = {"Up","Down","Left","Right","Select","Start","B","A"}
TRACE = false

local function state_str()
  local p = {"frame=" .. emu.framecount()}
  for _, f in ipairs(FIELDS) do
    p[#p+1] = f[1] .. "=" .. mainmemory.read_u8(f[2])
  end
  p[#p+1] = "lag=" .. emu.lagcount()
  return table.concat(p, " ")
end

local function parse_buttons(s)
  local t = {}
  for _, b in ipairs(BUTTONS) do t[b] = false end
  if s and s ~= "-" then
    for b in string.gmatch(s, "[^,]+") do t[b] = true end
  end
  return t
end

local function tohex(arr)
  local out = {}
  for i = 0, #arr do
    if arr[i] ~= nil then out[#out+1] = string.format("%02x", arr[i]) end
  end
  return table.concat(out)
end

local function send(line)
  conn:settimeout(5)
  conn:send(line .. "\n")
  conn:settimeout(0.05)
end

-- 'branch' (added 2026-10-09, Second Quest M3 / plan X6): evaluate K input strings from the current state inside
-- Lua, in one TCP round trip, and come back to the exact state we started from.
--   branch <addrs> <cps> [stopne=A] [stopeq=A:V] <s1> <s2> ... <sK>
--     addrs  RAM to sample: "a" or "a+n" items, comma separated, decimal (e.g. 24+13,112,132)
--     cps    checkpoints: "-" (end only), "c1,c2,..." (sample after that many frames of the string), "*N" (every N)
--     stopne=A   end a string early on the first frame RAM[A] differs from its value at the string's start
--     stopeq=A:V end a string early on the first frame RAM[A] == V
--     s      one input string: "." separated items "HH" or "HH:N" (hex button mask, N frames, default 1); the mask
--            bits are BUTTONS order: 1 Up, 2 Down, 4 Left, 8 Right, 16 Select, 32 Start, 64 B, 128 A (player 1)
--   reply  "ok K r1 r2 ... rK", each r = "<frames run>/<lag frames>/<f>:<hex>;<f>:<hex>;...": one sample per
--          checkpoint reached, then always the end sample (f = frames run). Hex follows the order of addrs.
-- The state is saved once (memorysavestate), reloaded before every string after the first and after the last one,
-- then freed. An error while running restores the state before the error is reported.
local BRANCH_PADS = {}
local function branch_pad(mask)
  local t = BRANCH_PADS[mask]
  if not t then
    t = {}
    local m = mask
    for _, b in ipairs(BUTTONS) do
      t[b] = (m % 2) == 1
      m = math.floor(m / 2)
    end
    BRANCH_PADS[mask] = t
  end
  return t
end

local function branch_sample(ranges)
  local out = {}
  for _, r in ipairs(ranges) do
    if r[2] == 1 then
      out[#out+1] = string.format("%02x", mainmemory.read_u8(r[1]))
    else
      local arr = mainmemory.read_bytes_as_array(r[1], r[2])
      for i = 0, r[2] do
        if arr[i] ~= nil then out[#out+1] = string.format("%02x", arr[i]) end
      end
    end
  end
  return table.concat(out)
end

local function branch_parse_string(tok)
  local pads, counts = {}, {}
  for item in string.gmatch(tok, "[^%.]+") do
    local hh, n = item:match("^(%x%x):(%d+)$")
    if not hh then hh = item:match("^(%x%x)$"); n = "1" end
    assert(hh, "branch: bad input item " .. item)
    pads[#pads+1] = branch_pad(tonumber(hh, 16))
    counts[#counts+1] = tonumber(n)
  end
  return {pads, counts}
end

local function branch_cmd(rest)
  local toks = {}
  for t in string.gmatch(rest, "%S+") do toks[#toks+1] = t end
  assert(#toks >= 2, "branch: need <addrs> <cps> [options] <strings>")
  local ranges = {}
  for item in string.gmatch(toks[1], "[^,]+") do
    local a, n = item:match("^(%d+)%+(%d+)$")
    if not a then a = item:match("^(%d+)$"); n = "1" end
    assert(a, "branch: bad address item " .. item)
    ranges[#ranges+1] = {tonumber(a), tonumber(n)}
  end
  local every, cps = nil, {}
  if toks[2]:sub(1, 1) == "*" then
    every = tonumber(toks[2]:sub(2)); assert(every and every > 0, "branch: bad checkpoint step")
  elseif toks[2] ~= "-" then
    for c in string.gmatch(toks[2], "[^,]+") do cps[#cps+1] = assert(tonumber(c), "branch: bad checkpoint") end
    table.sort(cps)
  end
  local stopne, stopeq, strs = {}, {}, {}
  for i = 3, #toks do
    local t = toks[i]
    local a = t:match("^stopne=(%d+)$")
    local ea, ev = t:match("^stopeq=(%d+):(%d+)$")
    if a then stopne[#stopne+1] = tonumber(a)
    elseif ea then stopeq[#stopeq+1] = {tonumber(ea), tonumber(ev)}
    else strs[#strs+1] = branch_parse_string(t) end
  end
  local results = {}
  local base = memorysavestate.savecorestate()
  local okr, rerr = pcall(function()
    for k, s in ipairs(strs) do
      if k > 1 then memorysavestate.loadcorestate(base) end
      local ne0 = {}
      for j, a in ipairs(stopne) do ne0[j] = mainmemory.read_u8(a) end
      local lag0 = emu.lagcount()
      local samples, f, ci, stopped = {}, 0, 1, false
      local pads, counts = s[1], s[2]
      for p = 1, #pads do
        local pad = pads[p]
        for _ = 1, counts[p] do
          joypad.set(pad, 1)
          emu.frameadvance()
          f = f + 1
          if every then
            if f % every == 0 then samples[#samples+1] = f .. ":" .. branch_sample(ranges) end
          else
            while cps[ci] and cps[ci] < f do ci = ci + 1 end
            if cps[ci] == f then samples[#samples+1] = f .. ":" .. branch_sample(ranges); ci = ci + 1 end
          end
          for j, a in ipairs(stopne) do
            if mainmemory.read_u8(a) ~= ne0[j] then stopped = true end
          end
          for _, e in ipairs(stopeq) do
            if mainmemory.read_u8(e[1]) == e[2] then stopped = true end
          end
          if stopped then break end
        end
        if stopped then break end
      end
      samples[#samples+1] = f .. ":" .. branch_sample(ranges)
      results[#results+1] = f .. "/" .. (emu.lagcount() - lag0) .. "/" .. table.concat(samples, ";")
    end
  end)
  memorysavestate.loadcorestate(base)
  memorysavestate.removestate(base)
  if not okr then error(rerr) end
  local head = "ok " .. #results
  if #results == 0 then return head end
  return head .. " " .. table.concat(results, " ")
end

local function handle(line)
  local cmd, rest = line:match("^(%S+)%s*(.*)$")
  if cmd == "ping" then
    send("pong")
  elseif cmd == "step" then
    local n, btn = rest:match("^(%d+)%s*(%S*)$")
    n = tonumber(n) or 1
    local t = parse_buttons(btn)
    if TRACE then
      local lines = {}
      for _ = 1, n do
        joypad.set(t, 1)
        emu.frameadvance()
        lines[#lines+1] = state_str()
      end
      send(table.concat(lines, ";"))
    else
      for _ = 1, n do
        joypad.set(t, 1)
        emu.frameadvance()
      end
      send(state_str())
    end
  elseif cmd == "stepm" then
    -- movie playback: advance without touching the joypad so the movie's own inputs apply
    local n = tonumber(rest) or 1
    for _ = 1, n do emu.frameadvance() end
    send(state_str())
  elseif cmd == "fields" then
    if rest == "default" or rest == "" then
      FIELDS = DEFAULT_FIELDS
    else
      local t = {}
      for name, addr in string.gmatch(rest, "([%w_]+):(%d+)") do t[#t+1] = {name, tonumber(addr)} end
      FIELDS = t
    end
    send("ok " .. #FIELDS)
  elseif cmd == "trace" then
    TRACE = (rest == "on"); send("ok")
  elseif cmd == "state" then
    send(state_str())
  elseif cmd == "ram" then
    local a, l = rest:match("^(%d+)%s+(%d+)$")
    local arr = mainmemory.read_bytes_as_array(tonumber(a), tonumber(l))
    send(tohex(arr))
  elseif cmd == "ramd" then
    local dom, a, l = rest:match("^(%S+)%s+(%d+)%s+(%d+)$")
    local arr = memory.read_bytes_as_array(tonumber(a), tonumber(l), dom)
    send(tohex(arr))
  elseif cmd == "branch" then
    send(branch_cmd(rest))
  elseif cmd == "msave" then
    send(memorysavestate.savecorestate())                    -- in-RAM state, fast
  elseif cmd == "mload" then
    memorysavestate.loadcorestate(rest); send("ok")
  elseif cmd == "mfree" then
    memorysavestate.removestate(rest); send("ok")
  elseif cmd == "save" then
    savestate.save(rest, true); send("ok")
  elseif cmd == "load" then
    local r = savestate.load(rest, true); send(r and "ok" or "fail")
  elseif cmd == "screenshot" then
    client.screenshot(rest); send("ok")
  elseif cmd == "fast" then
    emu.limitframerate(false); client.SetSoundOn(false); send("ok")
  elseif cmd == "normal" then
    emu.limitframerate(true); send("ok")
  elseif cmd == "frameskip" then
    -- draw only every Nth frame while searching: the emulation itself is untouched
    client.frameskip(tonumber(rest) or 0); send("ok")
  elseif cmd == "apikeys" then
    local names = {}
    for k, _ in pairs(_G[rest] or {}) do names[#names+1] = k end
    table.sort(names); send(table.concat(names, ","))
  elseif cmd == "reset" then
    client.reboot_core(); send(state_str())
  elseif cmd == "quit" then
    send("bye"); conn:close(); client.exit()
  else
    send("err unknown command: " .. tostring(cmd))
  end
end

client.unpause()
-- Block for commands. Yielding while idle lets the emulator free-run (frames advanced with no
-- input from us and broke replay determinism), so the script holds the main thread instead.
conn:settimeout(nil)
while true do
  local line, e = conn:receive("*l")
  if line then
    local okh, herr = pcall(handle, line)
    if not okh then send("err " .. tostring(herr)) end
  elseif e == "closed" then
    console.log("bridge: connection closed, exiting")
    client.exit()
    break
  end
end
