"""verify11: like-for-like time, margin and splits (pose convention), from my own measurements.
Ours: NesHawk pictures (verify11_pics.json). Record: Twitch 1480365509 frames A = round((PTS-60)*60), START A733 and END
A117026 re-checked by eye on frames I extracted myself (logs/m11/verify11_vod); record SPLIT poses are NOT re-measured:
knowledge/q2/record_events.json pose_video_frame - 2 (verify3 -> verify9 numbering, verify9 section 4).
    python verify11_times.py > logs/m11/verify11_times.txt
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "logs" / "m11"
NES = 60.0988  # NTSC NES frame rate (39375000/655171)
VID = 60.0


def mss(s):
    m, r = divmod(s, 60)
    return f"{int(m)}:{r:05.2f}"


p = json.loads((OUT / "verify11_pics.json").read_text())
rec = json.loads((HERE / "knowledge" / "q2" / "record_events.json").read_text())
S_OUR, E_OUR = p["start_pic"], p["end_pic"]
S_WR, E_WR = 733, 117026
ours = E_OUR - S_OUR
his_v = E_WR - S_WR
his_n = his_v * NES / VID
print(f"OURS  picture {S_OUR} (Link appears) -> picture {E_OUR} (Link beside Zelda) = {ours} NES frames = "
      f"{ours / NES:.3f} s = {mss(ours / NES)}")
print(f"HIS   A{S_WR} -> A{E_WR} = {his_v} video frames = {his_v / VID:.3f} s = {mss(his_v / VID)} = {his_n:.1f} NES frames")
mg = his_n - ours
print(f"MARGIN {mg:.1f} NES frames = {mg / NES:.3f} s in our favour (+-3 f = +-0.05 s measurement; "
      f"+-100 ppm clock -> +-{his_v / VID * 1e-4:.2f} s)")
print(f"cross-check with his LiveSplit 32:18.20: {1938.20 - ours / NES:.2f} s")
print(f"builder's convention (first mode-$13 frame 112,493 - C0 235 = 112,258 = 31:07.89): our END picture is "
      f"first-mode-$13 - 4 here ({112493 - E_OUR}), start picture = C0 - 1")

names = ["L2", "L1", "L8", "L4", "L5", "L6", "L3", "L7"]
ev = [e for e in rec["events"] if e.get("pose_video_frame")]
lsp = ["3:36.4", "8:06.2", "10:24.1", "14:49.2", "19:27.2", "21:33.4", "23:23.0", "27:19.6", "32:18.2"]
print("\nSPLITS (pose = first picture with Link holding the Triforce up and the B/A boxes empty; END = beside Zelda)")
print("split  our pose pic  ours NES f  ours time | his pose A  his NES f  his time | ours-his f    s  | his LiveSplit")
rows = []
prev_o = prev_h = 0.0
for k, nm in enumerate(names + ["Zelda"]):
    if nm == "Zelda":
        po, A = E_OUR, E_WR
    else:
        po = p["split_pose_pics"][k]
        e = next(e for e in ev if e["name"].startswith(nm + " ") or e["name"].startswith(nm + "b "))
        A = e["pose_video_frame"] - 2
    o = po - S_OUR
    h = (A - S_WR) * NES / VID
    rows.append({"split": nm, "our_pose_pic": po, "ours_nes": o, "his_A": A, "his_nes": round(h, 1),
                 "delta_nes": round(o - h, 1), "seg_ours": o - prev_o, "seg_his": round(h - prev_h, 1)})
    print(f"{nm:5s}  {po:12d}  {o:10d}  {mss(o / NES):>9s} | {A:10d}  {h:9.1f}  {mss(h / NES):>8s} | "
          f"{o - h:+8.1f} {(o - h) / NES:+6.2f} | {lsp[k]}")
    prev_o, prev_h = o, h
print("\nSEGMENTS (NES frames): split, ours, his, ours-his")
for r in rows:
    print(f"  {r['split']:5s} {r['seg_ours']:8.0f} {r['seg_his']:9.1f} {r['seg_ours'] - r['seg_his']:+8.1f}")
(OUT / "verify11_times.json").write_text(json.dumps({"ours": ours, "his_video": his_v, "his_nes": his_n,
                                                       "margin_nes": mg, "margin_s": mg / NES, "splits": rows},
                                                      indent=1), encoding="utf-8")
