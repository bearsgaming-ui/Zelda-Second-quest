﻿"""verify11 (copy of verify9_vodsheet.py): contact sheet of the record VOD frames. A = absolute video frame = round((PTS - 60.0) * 60).
    python verify9_vodsheet.py <segdir> <A_of_k001> <A_first> <A_last> <out.png> [crop x0,y0,x1,y1] [scale]
"""
import sys
from pathlib import Path
from PIL import Image, ImageDraw

seg, a0, lo, hi, out = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
crop = tuple(int(v) for v in sys.argv[6].split(",")) if len(sys.argv) > 6 else (0, 0, 1280, 720)
sc = float(sys.argv[7]) if len(sys.argv) > 7 else 0.35
ims = []
for A in range(lo, hi + 1):
    im = Image.open(seg / f"k{A - a0 + 1:03d}.png").convert("RGB").crop(crop)
    im = im.resize((int(im.width * sc), int(im.height * sc)))
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, 70, 14), fill=(0, 0, 0))
    d.text((2, 1), f"A{A}", fill=(255, 255, 0))
    ims.append(im)
cols = 5
w, h = ims[0].size
sheet = Image.new("RGB", (w * cols, h * ((len(ims) + cols - 1) // cols)), (40, 40, 40))
for i, im in enumerate(ims):
    sheet.paste(im, ((i % cols) * w, (i // cols) * h))
sheet.save(out)
print(out, sheet.size)

