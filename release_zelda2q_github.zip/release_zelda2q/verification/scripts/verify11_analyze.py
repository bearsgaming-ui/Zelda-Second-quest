﻿"""verify11: analyse my two replays of h1 (verify11_replay.py outputs; copy of verify11_analyze.py + extras). Own code; addresses from the public Zelda RAM map
used by the earlier verifiers (mode $12, level $10, room $EB, Link X $70 / Y $84 / facing $98, hearts $66F/$670,
invincibility $4F0, quest $62D, death counts $630-2, pads $F8-$FB).
    python verify11_analyze.py  > logs/m11/verify11_analysis.txt
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from verify6_replay import read_log  # noqa: E402

OUT = HERE / "logs" / "m11"
BIT = {"Right": 1, "Left": 2, "Down": 4, "Up": 8, "Start": 16, "Select": 32, "B": 64, "A": 128}
LEVELS = {}
res = {"checks": {}}


def check(name, ok, msg):
    res["checks"][name] = bool(ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: {msg}")


def main():
    m1 = json.loads((OUT / "verify11_r1.meta.json").read_text())
    m2 = json.loads((OUT / "verify11_r2.meta.json").read_text())
    head, frames, bad = read_log(HERE / "logs" / "m10" / "h1.inputs.txt")
    n = len(frames)
    print("=== 1. REPLAYS ===")
    for m in (m1, m2):
        print(f"  {m['tag']}: pid {m['pid']} core {m['config_preferred_core_NES']} saveram at launch "
              f"{m['saveram_files_at_launch']} power-on RAM {m['poweron_ram_sha1']} power-on cart RAM bytes "
              f"{m['poweron_wram_distinct_bytes']} final RAM {m['final_ram_sha1']} lag {m['lag_total']} "
              f"framecount {m['framecount_first_last']} step_ok {m['framecount_step_ok']} {m['seconds']} s "
              f"bridge writes {m['bridge_write_words_found']} complete {m['complete']}")
    H1 = np.load(OUT / "verify11_r1.hr.npy"); H2 = np.load(OUT / "verify11_r2.hr.npy")
    W1 = np.load(OUT / "verify11_r1.hw.npy"); W2 = np.load(OUT / "verify11_r2.hw.npy")
    F1 = np.load(OUT / "verify11_r1.fc.npy"); F2 = np.load(OUT / "verify11_r2.fc.npy")
    rd = np.nonzero(np.any(H1 != H2, axis=1))[0]; wd = np.nonzero(np.any(W1 != W2, axis=1))[0]
    check("replay.identical", len(rd) == 0 and len(wd) == 0 and np.array_equal(F1, F2),
          f"RAM sha1 differs on {len(rd)} rows, cart-RAM sha1 on {len(wd)} rows, of {n + 1}; framecount/lag equal "
          f"{np.array_equal(F1, F2)}")
    check("replay.final_sha1", m1["final_ram_sha1"] == m2["final_ram_sha1"] == "c791376abf0b61d1148560cf808287d6851aede9",
          f"final RAM sha1 {m1['final_ram_sha1']} (builder claims c791376a...)")
    check("replay.fresh", m1["poweron_wram_distinct_bytes"] == [0] == m2["poweron_wram_distinct_bytes"]
          and not m1["saveram_files_at_launch"] and not m2["saveram_files_at_launch"]
          and m1["framecount_first_last"][0] <= 1, "blank cart RAM and no SaveRAM file at power-on in both")
    check("replay.core", m1["config_preferred_core_NES"] == "NesHawk" == m2["config_preferred_core_NES"], "NesHawk both")
    print(f"  all-frames hash r1 {m1['all_frames_hash_sha1']} r2 {m2['all_frames_hash_sha1']}")

    R = np.load(OUT / "verify11_r1.ram.npy", mmap_mode="r")
    R = np.asarray(R)
    G9 = OUT.parent / "m9" / "verify9_r1.ram.npy"
    if G9.exists():  # read-only comparison with the earlier verified g1 run (h1 = g1 up to input 98,627)
        G = np.load(G9, mmap_mode="r")
        k = min(len(G), len(R))
        diff = next((i for i in range(0, k, 1) if not np.array_equal(G[i], R[i])), None)
        print(f"  g1 vs h1 full RAM: first differing row {diff} (inputs diverge at 98,628)")
    import hashlib
    spot = [0, 1000, 50000, n]
    okh = all(hashlib.sha1(R[i].tobytes()).digest() == H1[i].tobytes() for i in spot)
    check("ramdump.matches_hashes", okh, f"kept RAM rows {spot} hash to the per-frame sha1s")
    mode, lvl, room = R[:, 0x12].astype(int), R[:, 0x10].astype(int), R[:, 0xEB].astype(int)
    X, Y, face = R[:, 0x70].astype(int), R[:, 0x84].astype(int), R[:, 0x98].astype(int)

    print("\n=== 2. INPUTS / PADS ===")
    print(f"  {n} inputs, input sha1 {m1['inputs_sha1']}, header {head}")
    check("inputs.scan", not bad, f"only controller-1 tokens, no L+R/U+D: {len(bad)} problems {bad[:5]}")
    p2 = np.nonzero((R[1:, 0xF9] != 0) | (R[1:, 0xFB] != 0))[0] + 1
    check("pad.p2_never", len(p2) == 0, f"controller-2 bytes $F9/$FB nonzero on {len(p2)} frames {p2[:5].tolist()}")
    mask = np.array([0] + [sum(BIT[b] for b in f) for f in frames])
    fa = R[:, 0xFA].astype(int)
    extra = [int(i) for i in range(1, n + 1) if (fa[i] & ~mask[i]) and fa[i] != fa[i - 1]]
    check("pad.p1_no_phantom", not extra, f"game never latched a P1 button the log lacks ({extra[:10]})")
    c = Counter()
    for i in range(1, n + 1):
        for b in ("Start", "Select"):
            if b in frames[i - 1] and (i == 1 or b not in frames[i - 2]):
                c[b] += 1
    print(f"  Start presses {c['Start']}, Select presses {c['Select']}")

    print("\n=== 3. MODES / FILE / DEATH ===")
    seen = sorted(set(mode.tolist()))
    print("  modes seen:", {f"${v:02X}": int((mode == v).sum()) for v in seen})
    M = int(np.argmax((mode == 5) & (lvl == 0)))
    check("no_death", 0x11 not in seen, f"mode $11 on {int((mode == 0x11).sum())} frames")
    check("no_continue_save_retry", 8 not in seen and 0xD not in seen,
          f"mode $08 {int((mode == 8).sum())} f, mode $0D {int((mode == 0xD).sum())} f")
    back = [int(i) for i in range(M, n + 1) if mode[i] in (0, 1, 0xE, 0xF)]
    fcg = R[:, 0x15].astype(int); d = (fcg[1:] - fcg[:-1]) % 256
    badfc = [int(i) for i in np.nonzero((d != 1) & (d != 0))[0] + 1 if i > 3]
    check("no_reset", not back and not badfc, f"title/file modes after M: {len(back)}; $15 jumps {badfc[:8]}")
    check("deaths_zero", int(R[M:, 0x630:0x633].max()) == 0, f"death counts $630-2 at end {R[n, 0x630:0x633].tolist()}")
    check("second_quest", int(R[M:, 0x62D].min()) == 1 == int(R[M:, 0x62D].max()), "quest $62D = 1 on every play frame")
    pre = sorted(set(mode[:M].tolist()))
    print(f"  modes before the first play frame: {[f'${v:02X}' for v in pre]} (title / file select / register)")
    # a fresh file: the name was registered in this run (mode $0E seen), slot 1 had no game before
    check("fresh_file", 0x0E in pre, "register-your-name mode $0E used before play (new file made in this run)")

    print("\n=== 4. START ===")
    first_move = None
    for i in range(M + 1, M + 60):
        if (X[i], Y[i], face[i]) != (X[M], Y[M], face[M]):
            first_move = i
            break
    first_held = next(i for i in range(1, n + 1) if frames[i - 1] and i > M - 5)
    print(f"  first mode-5 frame on the overworld M = input {M}: room {room[M]:02X} Link ({X[M]},{Y[M]}) face {face[M]}")
    print(f"  rows M-3..M+4 mode/sub: {[(i, f'{mode[i]:02X}/{R[i, 0x13]:02X}') for i in range(M - 3, M + 5)]}")
    print(f"  first input line with a button at/after M-4: {first_held} {frames[first_held - 1]}")
    print(f"  first frame Link's X/Y/facing differs from M: {first_move} ({X[first_move]},{Y[first_move]}) "
          f"face {face[first_move]}; input lines {M+1}..{first_move}: {[frames[i - 1] for i in range(M + 1, first_move + 1)]}")
    res["M"] = M; res["first_move"] = first_move

    print("\n=== 5. SPLITS / END ===")
    t12 = [int(i) for i in range(1, n + 1) if mode[i] == 0x12 and mode[i - 1] != 0x12]
    for i in t12:
        print(f"  mode $12 first frame input {i} level {lvl[i]} room {room[i]:02X}: clock (C0=M+1) {i - (M + 1)}")
    t13 = [int(i) for i in range(1, n + 1) if mode[i] == 0x13 and mode[i - 1] != 0x13]
    print(f"  mode $13 first frames: {t13}; level {lvl[t13[0]] if t13 else None}")
    if t13:
        e = t13[0]
        print(f"  rows e-4..last: {[(i, f'{mode[i]:02X}/{R[i, 0x13]:02X}', X[i], Y[i], face[i]) for i in range(e - 4, n + 1)]}")
        print(f"  END clock (first mode-$13 frame - C0) = {e - (M + 1)}")
    res["t12"] = t12; res["t13"] = t13

    print("\n=== 6. HEARTS ON EVERY FRAME (from M) ===")
    hv, hp = R[:, 0x66F].astype(int), R[:, 0x670].astype(int)
    cont = (hv >> 4) + 1
    raw = (hv & 15) * 256 + hp
    changes = []
    for i in range(M + 1, n + 1):
        if hv[i] != hv[i - 1] or hp[i] != hp[i - 1]:
            kind = "DOWN" if raw[i] < raw[i - 1] else "up"
            if cont[i] != cont[i - 1]:
                kind += " container"
            changes.append(i)
            hit = any(R[j - 1, 0x4F0] == 0 and R[j, 0x4F0] != 0 for j in range(max(1, i - 2), i + 3))
            print(f"  {i:6d} clk {i - M - 1:6d} L{lvl[i]} room {room[i]:02X} mode ${mode[i]:02X} ({X[i]},{Y[i]}) "
                  f"{raw[i - 1] / 256:.3f}/{cont[i - 1]} -> {raw[i] / 256:.3f}/{cont[i]} {kind}"
                  f"{' [Link hit: $4F0 0->n within 2 f]' if hit else ''}")
    dec = [int(i) for i in range(M + 1, n + 1) if raw[i] < raw[i - 1] and cont[i] == cont[i - 1]]
    print(f"  frames with a heart LOSS: {dec}; total lost {sum(int(raw[i - 1] - raw[i]) for i in dec) / 256:.3f} hearts")
    print(f"  min raw hearts after M: {raw[M:].min() / 256:.3f} at input {M + int(np.argmin(raw[M:]))}")
    touches = [int(i) for i in range(M + 1, n + 1) if R[i - 1, 0x4F0] == 0 and R[i, 0x4F0] != 0]
    print(f"  Link-touch events ($4F0 0 -> n): {len(touches)}")
    for i in touches:
        near = []
        for s in range(1, 12):
            t = int(R[i - 1, 0x34F + s])
            if t and abs(int(R[i - 1, 0x70 + s]) - X[i - 1]) <= 24 and abs(int(R[i - 1, 0x84 + s]) - Y[i - 1]) <= 24:
                near.append(f"${t:02X}")
        print(f"    {i:6d} L{lvl[i]} room {room[i]:02X} mode ${mode[i]:02X} hearts {raw[i - 1] / 256:.3f}->"
              f"{raw[min(n, i + 2)] / 256:.3f} near {near}")
    res["heart_loss_frames"] = dec
    res["touches"] = touches

    print("\n=== 7. DETAIL OF EVERY HEART DROP (incl. container) ===")
    rup = R[:, 0x66D].astype(int)
    for i in range(M + 1, n + 1):
        if raw[i] < raw[i - 1] or cont[i] < cont[i - 1]:
            objs = []
            for s in range(1, 12):
                t = int(R[i - 1, 0x34F + s])
                if t:
                    objs.append(f"${t:02X}@({int(R[i - 1, 0x70 + s])},{int(R[i - 1, 0x84 + s])})")
            print(f"  {i}: L{lvl[i]} room {room[i]:02X} Link ({X[i - 1]},{Y[i - 1]}) {raw[i - 1] / 256:.3f}/{cont[i - 1]}"
                  f" -> {raw[i] / 256:.3f}/{cont[i]}; $4F0 {[int(R[j, 0x4F0]) for j in range(i - 2, min(n, i + 3) + 1)]};"
                  f" rupees {rup[i - 1]}->{rup[i]}; objects {objs}")

    print("\n=== 8. END ROWS (RAM) ===")
    if t13:
        e = t13[0]
        for i in range(e - 14, n + 1):
            zl = [f"${int(R[i, 0x34F + s]):02X}@({int(R[i, 0x70 + s])},{int(R[i, 0x84 + s])})" for s in range(1, 12)
                  if R[i, 0x34F + s]]
            print(f"  {i}: mode {mode[i]:02X}/{R[i, 0x13]:02X} L{lvl[i]} room {room[i]:02X} Link ({X[i]},{Y[i]}) "
                  f"face {face[i]} input {frames[i - 1] if i else ()} objs {zl}")
        fin = (X[n], Y[n])
        k = n
        while k > 0 and (X[k - 1], Y[k - 1]) == fin:
            k -= 1
        print(f"  RAM: Link reaches his final spot {fin} at input {k} and stays there to the end")
        res["ram_final_spot_from"] = int(k)
    res["inputs_n"] = n
    res["levels_t12"] = [int(lvl[i]) for i in t12]
    (OUT / "verify11_analysis.json").write_text(json.dumps(res, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()

