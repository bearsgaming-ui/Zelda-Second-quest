"""verify11: picture detectors on my own NesHawk screenshots ("picture i" = screenshot right after input i).
  START: first picture with Link's green tunic colour (137,217,0) in the play field (rows >= 64).
  END:   first picture with Link's green to the RIGHT of Zelda at her height (x 136..155, y 124..148) and none of
         Link's green below her (x 112..140, y 146..170).
  SPLIT pose: first picture at/after the first mode-$12 frame whose B and A item boxes are both empty (Link raises
         the Triforce in the same picture) = the pose used for the record's splits (record_events.json).
    python verify11_pics.py   (needs logs/m11/verify11_analysis.json)
"""
import json
from pathlib import Path

import numpy as np
from PIL import Image

HERE = Path(__file__).resolve().parent
OUT = HERE / "logs" / "m11"
D = OUT / "verify11_shots"
GREEN = np.array([137, 217, 0])


def pic(tag, i):
    p = D / f"{tag}_i{i:06d}.png"
    if not p.exists():
        p = D / f"{tag}_x{i:06d}.png"
    return np.asarray(Image.open(p).convert("RGB")).astype(int) if p.exists() else None


def green(a, x0, x1, y0, y1):
    return int(np.all(a[y0:y1, x0:x1] == GREEN, axis=2).sum())


def boxes_empty(a):
    b = a[22:43, 126:138]
    aa = a[22:43, 150:163]
    return int((b.sum(axis=2) > 0).sum()), int((aa.sum(axis=2) > 0).sum())


def main():
    res = json.loads((OUT / "verify11_analysis.json").read_text())
    out = {}
    print("=== START (r1 pictures 220-250) ===")
    for i in range(225, 245):
        a = pic("r1", i)
        print(f"  pic {i}: Link-green px in play field {green(a, 0, 256, 64, 224)}")
    st = next(i for i in range(220, 251) if green(pic("r1", i), 0, 256, 64, 224) > 0)
    print(f"  START picture (Link first appears) = {st}")
    out["start_pic"] = st

    print("=== END (r1 pictures 112380-end, x = extra no-button pictures after the last input) ===")
    n = res["inputs_n"]
    last = n + 12
    for i in range(n - 14, last + 1):
        a = pic("r1", i)
        if a is None:
            continue
        print(f"  pic {i}: beside-px {green(a, 136, 156, 124, 148)} below-px {green(a, 112, 141, 146, 171)}")
    en = next(i for i in range(112380, last + 1) if pic("r1", i) is not None
              and green(pic("r1", i), 136, 156, 124, 148) > 0 and green(pic("r1", i), 112, 141, 146, 171) == 0)
    stay = all(green(pic("r1", i), 136, 156, 124, 148) > 0 for i in range(en, last + 1) if pic("r1", i) is not None)
    print(f"  END picture (Link first beside Zelda) = {en}; stays beside to the last picture: {stay}")
    out["end_pic"] = en
    out["end_stays"] = stay

    print("=== SPLIT POSES (r2 pictures) ===")
    poses = []
    for t in res["t12"]:
        row = []
        pose = None
        for i in range(t - 8, t + 8):
            a = pic("r2", i)
            if a is None:
                continue
            bx = boxes_empty(a)
            row.append(f"{i}:{bx[0]}/{bx[1]}")
            # my box crop also catches a few border pixels: an empty box reads 6/4, a box with an item 38-64/56
            if pose is None and i >= t and bx[0] <= 10 and bx[1] <= 10:
                pose = i
        print(f"  T12 {t}: pose picture {pose} (T12+{None if pose is None else pose - t}); box px {' '.join(row)}")
        poses.append(pose)
    out["split_pose_pics"] = poses
    (OUT / "verify11_pics.json").write_text(json.dumps(out, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
