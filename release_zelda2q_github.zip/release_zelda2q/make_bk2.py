"""Write the BizHawk movie (.bk2) of the Zelda Second Quest run from its plain input file.

    python make_bk2.py zelda2q_ai_31m07s.inputs.txt zelda2q_ai_31m07s.bk2 [--tail 240] [--rom "Legend of Zelda, The (USA) (Rev 1).nes"]

The input file has one line per frame (buttons joined by ',', an empty line = no buttons, '#' lines are comments).
The run was built and checked through BizHawk's Lua bridge on the NesHawk core: the emulator is started from power-on,
BizHawk emulates frame 1 before Lua takes control, and line k of the file is the input of frame k + 1. In a BizHawk
movie, input-log line k is played on frame k, so the movie is ONE empty lead-in line followed by the file line for
line (movie line k + 1 = file line k). This alignment was measured on this game before the run was built: a NesHawk
movie made this way matched the bridge replay of a 136,527-frame First Quest run byte for byte at all 364 RAM dumps.
`--tail` idle lines are added after the last line so the ending (Link beside Zelda, the Triforce) is in the movie.

The header names the NesHawk core (EmuHawk switches to the core named in the header) and the SHA-1 BizHawk uses for
this cartridge (the ROM without its 16-byte iNES header). No savestate, no SaveRAM: the movie starts from power-on with
an empty battery save, and the run itself registers a new Second Quest file.
"""
import argparse
import hashlib
import zipfile
from pathlib import Path

ORDER = ("Up", "Down", "Left", "Right", "Select", "Start", "B", "A")
MNEMONIC = {"Up": "U", "Down": "D", "Left": "L", "Right": "R", "Select": "s", "Start": "S", "B": "B", "A": "A"}
LOG_KEY = "LogKey:#Reset|Power|#P1 Up|P1 Down|P1 Left|P1 Right|P1 Select|P1 Start|P1 B|P1 A|"
ROM_SHA1_HEADERLESS = "BE2F5DC8C5BA8EC1A344A71F9FB204750AF24FE7"   # Legend of Zelda, The (USA) (Rev 1), no iNES header
ROM_SHA1_WHOLE = "3701381A82FC7D52B2DD3E8892047B30A114AB43"        # the same file with its iNES header


def read_rows(path):
    rows = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.startswith("#"):
            continue
        btn = tuple(b.strip() for b in line.replace("+", ",").split(",") if b.strip())
        for b in btn:
            if b not in MNEMONIC:
                raise SystemExit(f"unknown button {b!r} in {path}")
        rows.append(set(btn))
    return rows


def movie_line(held):
    return "|..|" + "".join(MNEMONIC[b] if b in held else "." for b in ORDER) + "|"


def write_bk2(rows, out, comment):
    header = [
        "MovieVersion BizHawk v2.0.0",
        "Author Claude (Anthropic), via Claude Code",
        "emuVersion Version 2.11.1",
        "OriginalEmuVersion Version 2.11.1",
        "Platform NES",
        "SystemID NES",
        "GameName Legend of Zelda, The",
        f"SHA1 {ROM_SHA1_HEADERLESS}",
        "rerecordCount 0",
        "Core NesHawk",
        "BoardName SxROM",
    ]
    log = "[Input]\n" + LOG_KEY + "\n" + "\n".join(movie_line(r) for r in rows) + "\n[/Input]\n"
    tmp = Path(str(out) + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("Header.txt", "\n".join(header) + "\n")
        z.writestr("Input Log.txt", log)
        z.writestr("Comments.txt", comment + "\n")
        z.writestr("Subtitles.txt", "")
    tmp.replace(out)
    return len(rows)


def check_roundtrip(rows, out):
    """read the movie back: its input log must be the rows exactly"""
    with zipfile.ZipFile(out) as z:
        log = z.read("Input Log.txt").decode("utf-8").splitlines()
    assert log[0] == "[Input]" and log[1] == LOG_KEY and log[-1] == "[/Input]"
    body = log[2:-1]
    assert len(body) == len(rows), (len(body), len(rows))
    back = [{b for b, c in zip(ORDER, l[4:12]) if c != "."} for l in body]
    assert back == rows, "input log differs from the file"
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs")
    ap.add_argument("out")
    ap.add_argument("--tail", type=int, default=240)
    ap.add_argument("--rom", help="optional: check the ROM's hash")
    a = ap.parse_args()
    if a.rom:
        d = Path(a.rom).read_bytes()
        whole = hashlib.sha1(d).hexdigest().upper()
        bare = hashlib.sha1(d[16:] if d[:4] == b"NES\x1a" else d).hexdigest().upper()
        print("ROM SHA-1 whole", whole, "headerless", bare, "OK" if bare == ROM_SHA1_HEADERLESS else "DIFFERENT")
    rows = read_rows(a.inputs)
    n_file = len(rows)
    movie = [set()] + rows + [set()] * a.tail
    src_sha = hashlib.sha1(Path(a.inputs).read_bytes()).hexdigest()
    comment = (f"The Legend of Zelda (NES, USA Rev 1), Second Quest, Any% No Up+A, an AI-built run. 1 empty lead-in line + "
               f"{n_file} input lines from power-on (input file sha1 {src_sha}) + {a.tail} idle lines; movie line k+1 = "
               f"file line k. Link first appears on frame 235 (file line 234), first stands beside Zelda on frame "
               f"112,490 (picture of file line 112,489): 112,255 frames = 31:07.84 at 60.0988 fps. Core NesHawk, "
               f"BizHawk 2.11.1.")
    n = write_bk2(movie, a.out, comment)
    check_roundtrip(movie, a.out)
    print(f"wrote {a.out}: {n} movie frames (1 lead-in + {n_file} file lines + {a.tail} idle), input log == file: OK")


if __name__ == "__main__":
    main()
