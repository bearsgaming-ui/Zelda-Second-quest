# The Legend of Zelda, Second Quest, Any% No Up+A: AI run, 31:07.84

An AI built this run of The Legend of Zelda's Second Quest by search, under the human category's rules, with the
human world record's video as its route and its bar. Timed the same way as the record, it is **70.38 seconds**
under the human world record, **32:18 by Schicksal** (2022-05-10, https://www.twitch.tv/videos/1480365509).

| | frames | time |
|---|---|---|
| AI run (this file) | 112,255 NES frames | **31:07.84** |
| record (Schicksal) | 116,293 frames of his 60 fps video = 116,484.5 NES frames | 32:18.22 (his LiveSplit: 32:18.20) |
| margin | 4,229.5 +- 3 NES frames | **70.38 +- 0.05 s** (+- 0.2 s allowing +- 100 ppm for his capture's clock) |

Both runs are timed from the picture where Link first appears on the overworld to the picture where he first stands
beside Zelda (60.0988 NES frames a second).

## Files

| file | what |
|---|---|
| `zelda2q_ai_31m07s.inputs.txt` | the run: one input file from power-on, 112,493 input lines after a `#` header line (line k = the controller-1 buttons held on input k, joined by `,`; an empty line = nothing). SHA-1 `3e46e15b7dccff49a729319456632142e4d1c37e`. |
| `zelda2q_ai_31m07s.bk2` | the BizHawk 2.11.1 movie of it (NesHawk core): one empty lead-in line, the file line for line, then 240 idle lines so the ending is in the movie. |
| `make_bk2.py` | writes the movie from the input file and checks the movie's input log against the file. |
| `verify_bk2.py`, `verify_movie.lua` | play the movie with BizHawk's own movie player, hands-off, and check it (see below). |
| `verification/` | the independent re-check: `verify11_summary.txt` (verdict, method, numbers, problems found), `verify11_analysis.txt` (memory, health and game-mode checks on every frame), `verify11_pics.txt` / `verify11_times.txt` / `.json` (the events found in the pictures and the split table), `verify11_r1/r2.meta.json` (the two replays), the keyframe stills (`keyframes/`) and contact sheets (`*_sheet.png`). |
| `verification/scripts/` | the checker's own code (`verify11_*.py`) with the pieces of the project harness it imports (`verify6_replay.py`, `zelda/emulator.py`, `bridge.lua`). They expect the project's folder layout (paths in `zelda/emulator.py`); they are here so the method can be read and re-run, not as a packaged tool. |

Not included, on purpose: the ROM, save states, the project's search code, and any third-party disassembly. You need
your own **Legend of Zelda, The (USA) (Rev 1)** ROM: whole-file SHA-1 `3701381a82fc7d52b2dd3e8892047b30a114ab43`
(without the 16-byte iNES header `be2f5dc8c5ba8ec1a344a71f9fb204750af24fe7`, the hash BizHawk puts in the movie).

## The rules it played by

- **Leaderboard:** speedrun.com, The Legend of Zelda, Any% No Up+A, Second Quest. Timed from control of Link on the
  overworld to loss of control next to Zelda. Controller 2's Up+A (soft reset) is banned; start from power-on (no
  CONTINUE / SAVE / RETRY); screen wraps and block clips are allowed (the record uses both).
- **On top:** controller 1 only, never Left+Right or Up+Down together, one input file from power-on, no deaths.
- No TAS inputs are in the run. The route is the record's own (read from his HUD and his map screen), with a few
  screen wraps of our own. Built and checked on BizHawk 2.11.1, NesHawk core.

## How it was checked (verification/verify11_summary.txt)

The re-check was done by a separate checker with its own code; the builder's verify, clock and compliance code was
not used.

1. **Two replays from power-on**, two fresh isolated NesHawk instances, blank cartridge RAM, no SaveRAM file. The
   SHA-1 of the 2 KB RAM and of the 8 KB cartridge RAM is equal in both replays on all 112,494 frames (power-on + every
   input); final RAM SHA-1 `c791376abf0b61d1148560cf808287d6851aede9`. The input file parses with 0 problems:
   controller-1 buttons only, never Left+Right or Up+Down. Controller 2's bytes read 0 on every frame.
2. **Game state on every frame:** a new Second Quest file is registered in the run (quest byte = 1 on every play
   frame); no death, no CONTINUE / SAVE / RETRY, no title screen after play starts, no reset.
3. **Health on every frame:** 1.5 hearts of damage in the whole run, both before LEVEL-3: one touch on the overworld
   (input 23,287; a heart picked up on the next frame puts it back) and half a heart in LEVEL-6's room 54 (input
   71,256). The two heart containers given to old men ("money or life" rooms) are a route choice, not damage.
4. **Timing at identical on-screen events**, both runs read picture by picture:
   - ours (NesHawk pictures): Link first appears in the picture after input 234; he first stands beside Zelda in the
     picture after input 112,489. 112,489 - 234 = 112,255 frames = 31:07.84.
   - the record (his Twitch VOD, frames extracted with their timestamps, 60.000 fps): Link first appears in video
     frame 733, first beside Zelda in frame 117,026. 116,293 video frames = 116,484.5 NES frames = 32:18.22.
     Cross-check: his LiveSplit 32:18.20 - 31:07.84 = 70.36 s.
   - Margin 70.38 s +- 0.05 s (+- 1 video frame at each end, plus the HUD/Link start ambiguity); +- 0.2 s with a
     +- 100 ppm clock tolerance on his capture.
5. **Splits** (pose = the first picture with Link holding the Triforce up; record poses read from his video,
   +- 2 frames each):

   | Triforce | AI | record | AI - record |
   |---|---|---|---|
   | LEVEL-2 | 3:40.34 | 3:36.48 | +3.85 s |
   | LEVEL-1 | 8:00.68 | 8:06.33 | -5.66 s |
   | LEVEL-8 | 10:12.24 | 10:24.22 | -11.97 s |
   | LEVEL-4 | 14:26.46 | 14:49.35 | -22.89 s |
   | LEVEL-5 | 18:50.47 | 19:27.32 | -36.84 s |
   | LEVEL-6 | 20:54.90 | 21:33.57 | -38.67 s |
   | LEVEL-3 | 22:46.02 | 23:23.18 | -37.17 s |
   | LEVEL-7 | 26:19.70 | 27:19.73 | -60.03 s |
   | Zelda | 31:07.84 | 32:18.22 | -70.38 s |

   The builder's own claim (70.28 s) was correct but 6 frames too small, in the record's favour; the re-check's
   70.38 s is the number used everywhere.

## Play it yourself

1. BizHawk 2.11.1 (https://tasvideos.org/BizHawk), your own ROM (hashes above). Make sure no battery save of yours
   for this game is loaded (the run makes a new file; `verify_bk2.py` uses an empty save folder).
2. `python make_bk2.py zelda2q_ai_31m07s.inputs.txt zelda2q_ai_31m07s.bk2` re-creates the movie from the input file
   (it must come out identical to the one here).
3. `python verify_bk2.py --bizhawk "C:/path/BizHawk-2.11.1-win-x64" --rom "C:/path/Legend of Zelda, The (USA) (Rev 1).nes"`
   plays the movie in BizHawk's own movie player (no input injection, no memory writes, no save states) and checks
   the SHA-1 of the RAM after every frame against the re-check above, the first overworld frame (235), the ending
   frame (112,494), Second Quest on every play frame and no death / continue. Exit code 0 = PASS.

The movie alignment (one empty lead-in line) was measured on this game before the run was built: a NesHawk movie made
the same way matched the frame-by-frame bridge replay of a 136,527-frame First Quest run at all 364 RAM dumps. The
movie's own playback check on this run: **PASS** (2026-11-17, BizHawk 2.11.1, NesHawk, 595 s): the per-frame RAM
digest over frames 2..112,494 = `36ad3b245c3b82a730b48429880d4852a216365c` (the re-check's), RAM after the last input
`c791376a...`, first overworld frame 235, ending on frame 112,494, Second Quest on every play frame, no death or
continue; 20,542 lag frames after frame 1 (the re-check counts 20,543 including frame 1). Report:
`verification/bk2_playback.json`; the movie's pictures of the two timing events: `verification/bk2_shots/`
(f00234 empty sand, f00235 Link appears; f00112489 Link below Zelda, f00112490 Link beside her).

## The best TAS

This is a tool-assisted run too (an AI built it room by room with save states and frame-by-frame search), but under
the human category's rules. The published Second Quest TAS is **4715M by chatterbox, 24:48.75** from power-on
(89,472 frames, FCEUX; https://tasvideos.org/4715M). It uses controller 2's Up+A soft reset nine times, which this
category bans, so it is a different category and not comparable with this run or with the human record. As far as we
could find there is no published Second Quest TAS under No Up+A rules.

The Legend of Zelda (c) 1986 Nintendo. BizHawk (TASVideos). Record: Schicksal.
