"""Check the Zelda Second Quest movie with BizHawk's own movie playback: no input injection, no memory writes, no
savestates.

    python verify_bk2.py --bizhawk "C:/path/BizHawk-2.11.1-win-x64" --rom "C:/path/Legend of Zelda, The (USA) (Rev 1).nes" [zelda2q_ai_31m07s.bk2]

Needs Python 3.9+ and Pillow (pip install pillow). Windows (EmuHawk.exe). It starts one EmuHawk with a private copy
of your BizHawk config (rewind off, and an EMPTY folder for NES battery saves, so a save file of yours cannot change
the file-select screen; your own config file is not changed), plays the movie hands-off with verify_movie.lua for
112,734 frames (about half an hour on NesHawk), then checks:

  1. BizHawk loaded the movie, played it on the NesHawk core, from power-on (no savestate), with the expected ROM.
  2. The SHA-1 of the 2 KB RAM after every frame 2..112,494 (one digest per frame, the digests joined in order and
     hashed again) equals the independent re-check's: two fresh emulators fed the input file through BizHawk's Lua
     bridge, identical RAM on every frame (verification/verify11_summary.txt). RAM after frame 112,494 (the file's
     last line) = c791376abf0b61d1148560cf808287d6851aede9.
  3. Game state from RAM: Second Quest ($062D = 1) from the first overworld frame on, the first overworld frame
     (mode $12 = 5) is frame 235, no death (mode $11) and no CONTINUE / SAVE / RETRY (modes $08 / $0D) after it, and
     the ending (mode $13) starts on frame 112,494.
  4. Screenshots of frames 234 / 235 (Link appears) and 112,489 / 112,490 (Link beside Zelda) are kept with --keep.

The run's TIME comes from the pictures, the same way for both runs (verification/verify11_summary.txt): Link first
appears in the picture of frame 235, first stands beside Zelda in the picture of frame 112,490: 112,255 frames =
31:07.84 at 60.0988 frames a second.

Exit code 0 = everything matched, 1 = something did not (the report says what).
"""
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
TARGET = 112734                                            # 1 lead-in + 112,493 file lines + 240 idle
LAST = 112494                                              # frame of the file's last line
WANT_TRACE = "36ad3b245c3b82a730b48429880d4852a216365c"    # sha1 of the per-frame RAM sha1 digests, frames 2..112494
WANT_RAM_LAST = "c791376abf0b61d1148560cf808287d6851aede9"
WANT_CHECK = {10001: "7f101299978102fbf1336e30fea3472ef997a4c0", 50001: "ab0987fdd875f8dd80bf4f78d5bcdcc66a3199dd",
              100001: "175775f961fa222ed18910f5792466523752f30f"}   # RAM sha1 at a few frames, to find a divergence
WANT_OVERWORLD, WANT_END = 235, 112494
ROM_HEADERLESS_SHA1 = "be2f5dc8c5ba8ec1a344a71f9fb204750af24fe7"
ROM_WHOLE_SHA1 = "3701381a82fc7d52b2dd3e8892047b30a114ab43"
SHOTS = (234, 235, 112489, 112490)
NES_FPS = 60.0988
MODE, QUEST = 0x12, 0x062D


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("movie", nargs="?", default=str(HERE / "zelda2q_ai_31m07s.bk2"))
    ap.add_argument("--bizhawk", required=True, help="the BizHawk 2.11.1 folder (with EmuHawk.exe)")
    ap.add_argument("--rom", required=True, help="your Legend of Zelda, The (USA) (Rev 1) .nes file")
    ap.add_argument("--keep", action="store_true", help="keep the work folder (pictures, ram.bin, logs)")
    ap.add_argument("--timeout", type=float, default=7200)
    ap.add_argument("--json", help="also write the report to this file")
    a = ap.parse_args()

    biz = Path(a.bizhawk).resolve()
    rom = Path(a.rom).resolve()
    movie = Path(a.movie).resolve()
    lua = HERE / "verify_movie.lua"
    fails = []
    rep = {"movie": movie.name, "movie_sha1": hashlib.sha1(movie.read_bytes()).hexdigest()}

    data = rom.read_bytes()
    rep["rom_whole_sha1"] = hashlib.sha1(data).hexdigest()
    rep["rom_headerless_sha1"] = hashlib.sha1(data[16:] if data[:4] == b"NES\x1a" else data).hexdigest()
    if rep["rom_headerless_sha1"] != ROM_HEADERLESS_SHA1:
        fails.append("ROM is not The Legend of Zelda (USA) (Rev 1): headerless SHA-1 " + rep["rom_headerless_sha1"])

    work = Path(tempfile.mkdtemp(prefix="zelda2q_bk2_"))
    (work / "SaveRAM").mkdir()
    conf = {}
    cfg_src = biz / "config.ini"
    if cfg_src.exists():
        conf = json.loads(cfg_src.read_text(encoding="utf-8-sig"))
        if isinstance(conf.get("Rewind"), dict):
            conf["Rewind"]["Enabled"] = False
        conf["FrameSkip"] = 0
        conf["AutoLoadLastSaveSlot"] = False
        if isinstance(conf.get("Cheats"), dict):
            conf["Cheats"]["LoadFileByGame"] = False
        for e in (conf.get("PathEntries") or {}).get("Paths", []):
            if e.get("System") == "NES" and e.get("Type") == "Save RAM":
                e["Path"] = str(work / "SaveRAM")
    else:
        print("WARNING: no config.ini in the BizHawk folder; BizHawk's defaults are used (start it once first so a "
              "config exists, and make sure no Zelda .SaveRAM file of yours is in its NES SaveRAM folder)")
    cfg = work / "config.ini"
    if conf:
        cfg.write_text(json.dumps(conf, indent=1), encoding="utf-8")
    ud = f"frames:{TARGET};out:{work.as_posix()};shots:{'_'.join(map(str, SHOTS))}"
    args = [str(biz / "EmuHawk.exe")] + ([f"--config={cfg}"] if conf else []) + \
           [f"--lua={lua}", f"--userdata={ud}", f"--movie={movie}", str(rom)]
    t0 = time.time()
    with open(work / "emuhawk_stdout.log", "w") as so:
        proc = subprocess.Popen(args, cwd=str(biz), stdout=so, stderr=subprocess.STDOUT)
        print(f"EmuHawk pid {proc.pid}: playing {movie.name} to frame {TARGET} ...", flush=True)
        try:
            proc.wait(timeout=a.timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
            fails.append("EmuHawk did not finish in time (stopped)")
    rep["seconds"] = round(time.time() - t0, 1)

    log = (work / "movie.log").read_text(encoding="utf-8") if (work / "movie.log").exists() else ""
    kv = {}
    for line in log.splitlines():
        k, _, v = line.partition("=")
        kv.setdefault(k, v)
    rep["bizhawk"] = {k: kv.get(k) for k in ("start_framecount", "movie_loaded", "movie_mode", "movie_length",
                                             "movie_startsfromsavestate", "movie_startsfromsaveram",
                                             "movie_header Core", "movie_header SHA1", "romhash", "board",
                                             "end_framecount", "end_movie_mode")}
    if "DONE" not in log:
        fails.append("the Lua script did not finish: " + (log.splitlines()[-1] if log else "no log"))
    if kv.get("movie_loaded") != "true" or kv.get("movie_mode") != "PLAY":
        fails.append(f"movie not playing (loaded={kv.get('movie_loaded')}, mode={kv.get('movie_mode')})")
    if kv.get("movie_startsfromsavestate") not in (None, "false"):
        fails.append("movie starts from a savestate")
    if kv.get("movie_startsfromsaveram") not in (None, "false"):
        fails.append("movie starts from SaveRAM")
    doms = kv.get("domains", "")
    rep["core_seen"] = "NesHawk" if "PPU Bus" in doms.split("|") else "not NesHawk"   # quickerNES has no PPU Bus
    if rep["core_seen"] != "NesHawk":
        fails.append("core is not NesHawk (memory domains: " + doms + ")")

    # stream the trace: 3-byte frame number, lag flag, 2048 RAM bytes per frame
    R = 4 + 2048
    rb = work / "ram.bin"
    h = hashlib.sha1()
    expect_f, last_ram, lag = 2, None, 0
    ow, end, bad_modes, quest_bad, checks = None, None, [], [], {}
    prev_mode = None
    if rb.exists():
        with open(rb, "rb") as fh:
            while True:
                r = fh.read(R)
                if len(r) < R:
                    break
                f = r[0] | r[1] << 8 | r[2] << 16
                if f != expect_f:
                    fails.append(f"trace frame {f} where {expect_f} was expected")
                    break
                ram = r[4:]
                if f <= LAST:
                    d = hashlib.sha1(ram).digest()
                    h.update(d)
                    lag += r[3]
                    if f in WANT_CHECK:
                        checks[f] = d.hex()
                    if f == LAST:
                        last_ram = d.hex()
                m = ram[MODE]
                if ow is None and m == 5:
                    ow = f
                if ow is not None and f <= LAST:
                    if m in (0x08, 0x0D, 0x11) and m != prev_mode:
                        bad_modes.append((f, m))
                    if ram[QUEST] != 1:
                        quest_bad.append(f)
                if end is None and m == 0x13:
                    end = f
                prev_mode = m
                expect_f += 1
    rep["trace_last_frame"] = expect_f - 1
    if expect_f - 1 < LAST:
        fails.append(f"RAM trace stops at frame {expect_f - 1}")
    else:
        rep["trace_sha1_2_to_112494"] = h.hexdigest()
        rep["ram_sha1_at_112494"] = last_ram
        rep["lag_frames_2_to_112494"] = lag
        rep["ram_sha1_checkpoints"] = {str(k): checks.get(k) for k in WANT_CHECK}
        if rep["trace_sha1_2_to_112494"] != WANT_TRACE:
            fails.append(f"per-frame RAM trace sha1 {rep['trace_sha1_2_to_112494']}, expected {WANT_TRACE}")
            for k, v in WANT_CHECK.items():
                if checks.get(k) != v:
                    fails.append(f"  RAM already differs at frame {k} (or earlier)")
                    break
        if last_ram != WANT_RAM_LAST:
            fails.append(f"RAM sha1 at frame {LAST} is {last_ram}, expected {WANT_RAM_LAST}")
    rep["game"] = {"first_overworld_frame": ow, "ending_frame": end, "death_or_continue_modes": bad_modes[:10],
                   "frames_not_second_quest": len(quest_bad)}
    if ow != WANT_OVERWORLD:
        fails.append(f"first overworld frame {ow}, expected {WANT_OVERWORLD}")
    if end != WANT_END:
        fails.append(f"ending (mode $13) on frame {end}, expected {WANT_END}")
    if bad_modes:
        fails.append(f"death / CONTINUE / SAVE / RETRY mode seen: {bad_modes[:5]}")
    if quest_bad:
        fails.append(f"{len(quest_bad)} frames after the first overworld frame are not Second Quest (first {quest_bad[0]})")
    rep["shots"] = {f: (work / f"f{f:05d}.png").exists() for f in SHOTS}
    rep["time_from_pictures"] = "Link appears in frame 235's picture, beside Zelda in frame 112,490's: 112,255 frames = 31:07.84"

    rep["result"] = "PASS" if not fails else "FAIL"
    rep["failures"] = fails
    rep["checked_utc"] = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    print(json.dumps(rep, indent=1))
    if a.json:
        Path(a.json).write_text(json.dumps(rep, indent=1), encoding="utf-8")
    if a.keep or fails:
        print("work folder kept:", work)
    else:
        shutil.rmtree(work, ignore_errors=True)
    sys.exit(0 if not fails else 1)


if __name__ == "__main__":
    main()
